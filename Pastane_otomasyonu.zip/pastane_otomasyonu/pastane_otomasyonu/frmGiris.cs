﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace pastane_otomasyonu
{
    public partial class frmGiris : Form
    {
        public frmGiris()
        {
            InitializeComponent();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            string ad = textBox1.Text;
            string sifre = textBox2.Text;
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            OleDbCommand cmd = new OleDbCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "SELECT * FROM PERSONELLER where KULLANICI_AD='" + textBox1.Text + "' AND PAROLA='" + textBox2.Text + "'";
            OleDbDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                frmYonetim f2 = new frmYonetim();
                f2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı adı ya da şifre yanlış");
            }

            textBox1.Clear();
            textBox2.Clear();

            con.Close();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmUyeEkle fr1 = new frmUyeEkle();
            fr1.Show();

        }

        private void frmGiris_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmSifreDegistir f5 = new frmSifreDegistir();
            f5.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            frmSifreUnuttum f1 = new frmSifreUnuttum();
            f1.Show();
        }

        private void şİfremiUnuttumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSifreUnuttum f1 = new frmSifreUnuttum();
            f1.Show();
        }
    }
}


