﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace pastane_otomasyonu
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ad = textBox1.Text;
            string sifre = textBox2.Text;
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            OleDbCommand cmd = new OleDbCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "SELECT * FROM PERSONELLER where KULLANICI_AD='" + textBox1.Text + "' AND PAROLA='" + textBox2.Text + "'";
            OleDbDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read() && textBox1.Text =="admin")
            {
                frmPersonel f2 = new frmPersonel();
                f2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Burayı sadece yönetici görebilir.","BİLGİ");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }
    }
}
