﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Drawing.Printing;
namespace pastane_otomasyonu
{
    public partial class frmMalzeme : Form
    {
        public frmMalzeme()
        {
            InitializeComponent();
            listele();
        }
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
        OleDbCommand cmd = new OleDbCommand();
        public void listele()
        {
            OleDbConnection baglan = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            DataSet dtst = new DataSet();
            OleDbDataAdapter adtr = new OleDbDataAdapter();
            listView1.Items.Clear();
            baglan.Open();
            OleDbCommand komut = new OleDbCommand();
            komut.Connection = baglan;
            komut.CommandText = ("Select * FROM MALZEMELER");
            OleDbDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                ListViewItem ekle = new ListViewItem();

                ekle.Text = oku["MALZEME_ADI"].ToString();
                ekle.SubItems.Add(oku["FİYATI"].ToString());
                ekle.SubItems.Add(oku["Tarih"].ToString());
                ekle.SubItems.Add(oku["Kimlik"].ToString());
               



                listView1.Items.Add(ekle);
                

            }

            baglan.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listele();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            OleDbCommand cmd = new OleDbCommand();
            con.Open();
            cmd.Connection = con;
            if (textBox2.Text != "")
            {
                DialogResult secenek = MessageBox.Show("Kaydı silmek istiyor musunuz?", "Bilgilendirme Penceresi", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (secenek == DialogResult.Yes)
                {
                    cmd.CommandText = ("DELETE * FROM MALZEMELER WHERE Kimlik=" + textBox1.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Kayıt silindi.");
                    textBox2.Clear();
                    textBox1.Clear();
                    textBox4.Clear();

                }
                cmd.Dispose();
                con.Close();
                listele();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Text.Trim() != "" && textBox4.Text.Trim() != "")
                {
                    OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
                    OleDbCommand cmd = new OleDbCommand();
                    con.Open();
                    cmd.Connection = con;
                    cmd.CommandText = ("INSERT INTO MALZEMELER(MALZEME_ADI,FİYATI,Tarih) VALUES (@MALZEME_ADI,@FİYATI,@Tarih)");             
                    cmd.Parameters.AddWithValue("@MALZEME_ADI", textBox2.Text);         
                    cmd.Parameters.AddWithValue("@FİYATI", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Tarih", dateTimePicker1);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    con.Close();
                    textBox2.Clear();
                    textBox4.Clear();
                    listele();

                    MessageBox.Show("Kayıt işlemi tamamlandı ! ");
                }
                else
                {
                    MessageBox.Show("Boş alanları doldurunuz !!!");
                }
            }
            catch
            {
                MessageBox.Show("Kayıtlı malzeme.");
            }
        }

        private void frmMalzeme_Load(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                textBox2.Text = item.SubItems[0].Text;
                textBox4.Text = item.SubItems[1].Text;
                dateTimePicker1.Text = item.SubItems[2].Text;
                textBox1.Text = item.SubItems[3].Text;

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OleDbConnection bag = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
                 
            bag.Open();
            if (textBox2.Text != "")
            {
                string kayit = "update MALZEMELER set MALZEME_ADI=@MALZEME_ADI,FİYATI=@FİYATI,Tarih=@Tarih where Kimlik=@Kimlik";
                OleDbCommand komut = new OleDbCommand(kayit, bag);

                komut.Parameters.AddWithValue("@MALZEME_ADI", textBox2.Text);
                komut.Parameters.AddWithValue("@FİYATI", textBox4.Text);       
                komut.Parameters.AddWithValue("@Tarih", dateTimePicker1);
                komut.Parameters.AddWithValue("@Kimlik", textBox1.Text);


                komut.ExecuteNonQuery();

                bag.Close();
                MessageBox.Show("Malzeme bilgileri güncellendi.");
                textBox2.Clear();
                textBox1.Clear();
                textBox4.Clear();
                listele();
            }
            else
                MessageBox.Show("Güncellenicek kayıtı seçiniz.", "HATA");

           
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57)
            {
                e.Handled = false;//eğer rakamsa  yazdır.
            }

            else if ((int)e.KeyChar == ',' || ((int)e.KeyChar == 8))
            {
                e.Handled = false;//eğer basılan tuş , ise yazdır.
            }
            else
            {
                e.Handled = true;//bunların dışındaysa hiçbirisini yazdırma
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int kayitSayisi = -1;
            using (OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =PASTANE.accdb"))
            {
                OleDbCommand cmd = new OleDbCommand("select count(*) from MALZEMELER", con);
                con.Open();
                kayitSayisi = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();
            }

            label5.Text = (kayitSayisi + " adet kayıt bulunmaktadır.");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            string islem = "select sum(FİYATI) from MALZEMELER";
            baglanti.Open();
            OleDbCommand komut = new OleDbCommand(islem, baglanti);
            string toplam = komut.ExecuteScalar().ToString();
            komut.ExecuteNonQuery();
            label7.Text = (toplam + " TL");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
            dateTimePicker1.Text = "";
        }

        private void tariheGöreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMListeleme f1 = new frmMListeleme();
            f1.Show();
        }

        private void ismeGöreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMArama f1 = new frmMArama();
            f1.Show();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            
          PrintDocument printDocument1 = new PrintDocument();
          printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
          printDocument1.Print();
 
        }
        
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 10);
            float offset = e.MarginBounds.Top;
            offset += (font.GetHeight() + 50.0f);
            PointF location = new System.Drawing.PointF(e.MarginBounds.Left, offset);       
            e.Graphics.DrawString(columnHeader3.Text +"           "+ columnHeader6.Text +"                             "+ columnHeader1.Text +"                             "+ columnHeader2.Text+"                          ", font, Brushes.Black, location);
            e.Graphics.DrawString("  ", font, Brushes.Black, location); 
            foreach (ListViewItem Item in listView1.Items)
            {
                offset += (font.GetHeight() + 50.0f);

                // The 5.0f is to add a small space between lines
                PointF locationn = new System.Drawing.PointF(e.MarginBounds.Left, offset);

                e.Graphics.DrawString(Item.SubItems[0].Text + "                            " + Item.SubItems[1].Text + "                        " + Item.SubItems[2].Text + "                   " + Item.SubItems[3].Text + "                    ", font, Brushes.Black, locationn);




            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog preview = new PrintPreviewDialog();

             preview.Document = printDocument1;
        // Then show the dialog window.
        preview.Show();

           
        }

   

        private void baskıÖnizlemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog preview = new PrintPreviewDialog();

            preview.Document = printDocument1;
            // Then show the dialog window.
            preview.Show();

        }

        private void yazdırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDocument printDocument1 = new PrintDocument();
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printDocument1.Print();
        }
    }
}


