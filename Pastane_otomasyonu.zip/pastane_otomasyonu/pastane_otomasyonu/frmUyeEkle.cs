﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace pastane_otomasyonu
{
    public partial class frmUyeEkle : Form
    {

        public frmUyeEkle()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {


            try
            {

                if (textBox1.Text.Trim() != "" && textBox2.Text.Trim() != "" && textBox3.Text.Trim() != "" && textBox4.Text.Trim() != "" && textBox5.Text.Trim() != "" && textBox6.Text.Trim() != "")
                {
                    OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
                    OleDbCommand cmd = new OleDbCommand();
                    con.Open();

                    cmd.Connection = con;
                    if (textBox6.Text != "admin")
                    {
                        cmd.CommandText = ("INSERT INTO PERSONELLER(AD,SOYAD,YAŞ,TELEFON,PAROLA,KULLANICI_AD) VALUES (@AD,@SOYAD,@YAŞ,@TELEFON,@PAROLA,@KULLANICI_AD)");
                        cmd.Parameters.AddWithValue("@AD", textBox1.Text);
                        cmd.Parameters.AddWithValue("@SOYAD", textBox2.Text);
                        cmd.Parameters.AddWithValue("@YAŞ", textBox3.Text);
                        cmd.Parameters.AddWithValue("@TELEFON", textBox4.Text);
                        cmd.Parameters.AddWithValue("@PAROLA", textBox5.Text);
                        cmd.Parameters.AddWithValue("@KULLANICI_AD", textBox6.Text);
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();
                        con.Close();
                        textBox1.Clear();
                        textBox2.Clear();
                        textBox3.Clear();
                        textBox4.Clear();
                        textBox5.Clear();
                        textBox6.Clear();
                        MessageBox.Show("Kayıt işlemi tamamlandı ! ");
                    }
                    else
                        errorProvider1.SetError(textBox6, "Bu kullanıcı adını kullanamazsınız.");

                }

              
            

                
                   

                            

                else
                {

                        MessageBox.Show("Boş alanları doldurunuz !!!");
                    }
                }
            

            catch
            {

                MessageBox.Show("Bu üye zaten kayıtlı.");

            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57)
            {
                e.Handled = false;//eğer rakamsa  yazdır.
            }

            else if ((int)e.KeyChar == 8)
            {
                e.Handled = false;//eğer basılan tuş backspace ise yazdır.
            }
            else
            {
                e.Handled = true;//bunların dışındaysa hiçbirisini yazdırma
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57)
            {
                e.Handled = false;//eğer rakamsa  yazdır.
            }

            else if ((int)e.KeyChar == 8)
            {
                e.Handled = false;//eğer basılan tuş backspace ise yazdır.
            }
            else
            {
                e.Handled = true;//bunların dışındaysa hiçbirisini yazdırma
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            textBox5.PasswordChar = '*';
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBox4_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57)
            {
                e.Handled = false;//eğer rakamsa  yazdır.
            }

            else if ((int)e.KeyChar == 8)
            {
                e.Handled = false;//eğer basılan tuş backspace ise yazdır.
            }
            else
            {
                e.Handled = true;//bunların dışındaysa hiçbirisini yazdırma
            }
        }
    }
}
















