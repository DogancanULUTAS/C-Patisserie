﻿namespace pastane_otomasyonu
{
    partial class frmYonetim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmYonetim));
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.kullanıcılarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hesapBölümüToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masayaSiparişlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adreseSiparişlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malzemeListesiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-127, -17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "label1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(193, 228);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 13);
            this.label8.TabIndex = 5;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kullanıcılarToolStripMenuItem,
            this.hesapBölümüToolStripMenuItem,
            this.masayaSiparişlerToolStripMenuItem,
            this.adreseSiparişlerToolStripMenuItem,
            this.malzemeListesiToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(814, 24);
            this.menuStrip1.TabIndex = 14;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // kullanıcılarToolStripMenuItem
            // 
            this.kullanıcılarToolStripMenuItem.Name = "kullanıcılarToolStripMenuItem";
            this.kullanıcılarToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.kullanıcılarToolStripMenuItem.Text = "Kullanıcı İşlemleri";
            this.kullanıcılarToolStripMenuItem.Click += new System.EventHandler(this.kullanıcılarToolStripMenuItem_Click);
            // 
            // hesapBölümüToolStripMenuItem
            // 
            this.hesapBölümüToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.hesapBölümüToolStripMenuItem.Name = "hesapBölümüToolStripMenuItem";
            this.hesapBölümüToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.hesapBölümüToolStripMenuItem.Text = "Hesap Bölümü";
            this.hesapBölümüToolStripMenuItem.Click += new System.EventHandler(this.hesapBölümüToolStripMenuItem_Click);
            // 
            // masayaSiparişlerToolStripMenuItem
            // 
            this.masayaSiparişlerToolStripMenuItem.Name = "masayaSiparişlerToolStripMenuItem";
            this.masayaSiparişlerToolStripMenuItem.Size = new System.Drawing.Size(109, 20);
            this.masayaSiparişlerToolStripMenuItem.Text = "Masaya Siparişler";
            this.masayaSiparişlerToolStripMenuItem.Click += new System.EventHandler(this.masayaSiparişlerToolStripMenuItem_Click);
            // 
            // adreseSiparişlerToolStripMenuItem
            // 
            this.adreseSiparişlerToolStripMenuItem.Name = "adreseSiparişlerToolStripMenuItem";
            this.adreseSiparişlerToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.adreseSiparişlerToolStripMenuItem.Text = "Adrese Siparişler";
            this.adreseSiparişlerToolStripMenuItem.Click += new System.EventHandler(this.adreseSiparişlerToolStripMenuItem_Click);
            // 
            // malzemeListesiToolStripMenuItem
            // 
            this.malzemeListesiToolStripMenuItem.Name = "malzemeListesiToolStripMenuItem";
            this.malzemeListesiToolStripMenuItem.Size = new System.Drawing.Size(102, 20);
            this.malzemeListesiToolStripMenuItem.Text = "Malzeme Listesi";
            this.malzemeListesiToolStripMenuItem.Click += new System.EventHandler(this.malzemeListesiToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Chiller", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(83, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(647, 74);
            this.label1.TabIndex = 15;
            this.label1.Text = "Çınar Pastanesine Hoşgeldiniz...";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmYonetim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 433);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmYonetim";
            this.Text = "Ana Sayfa";
            this.Load += new System.EventHandler(this.frmYonetim_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem kullanıcılarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem malzemeListesiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hesapBölümüToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masayaSiparişlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adreseSiparişlerToolStripMenuItem;
        protected internal System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
    }
}