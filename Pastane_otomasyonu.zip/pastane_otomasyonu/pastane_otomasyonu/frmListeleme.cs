﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Drawing.Printing;
namespace pastane_otomasyonu
{
    public partial class frmListeleme : Form
    {
        public frmListeleme()
        {
            InitializeComponent();
            listele();
        }
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
        OleDbCommand cmd = new OleDbCommand();
        public void listele()
        {
            DataSet dtst = new DataSet();
            OleDbDataAdapter adtr = new OleDbDataAdapter();
            listView1.Items.Clear();
            con.Open();
            OleDbCommand komut = new OleDbCommand();
            komut.Connection = con;
            komut.CommandText = ("Select * FROM SATIS_HESAPALMA");
            OleDbDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                ListViewItem ekle = new ListViewItem();
                ekle.Text = oku["Urun_adi"].ToString();
                ekle.SubItems.Add(oku["ADEDI"].ToString());
                ekle.SubItems.Add(oku["FIYATI"].ToString());
                ekle.SubItems.Add(oku["Kimlik"].ToString());
                ekle.SubItems.Add(oku["TARİH"].ToString());
                listView1.Items.Add(ekle);
            }

            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            OleDbCommand cmd = new OleDbCommand();
            DataSet dtst = new DataSet();
            OleDbDataAdapter adtr = new OleDbDataAdapter();
            listView1.Items.Clear();
            con.Open();
            OleDbCommand komut = new OleDbCommand();
            komut.Connection = con;
            komut.CommandText = ("Select * FROM SATIS_HESAPALMA where TARİH BETWEEN @TARİH1 AND TARİH2");
            komut.Parameters.Add("@TARİH1", OleDbType.Date).Value = dateTimePicker1.Value;
            komut.Parameters.Add("@TARİH2", OleDbType.Date).Value = dateTimePicker2.Value;

            OleDbDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                ListViewItem ekle = new ListViewItem();
                ekle.Text = oku["Urun_adi"].ToString();
                ekle.SubItems.Add(oku["ADEDI"].ToString());
                ekle.SubItems.Add(oku["FIYATI"].ToString());
                ekle.SubItems.Add(oku["Kimlik"].ToString());
                ekle.SubItems.Add(oku["TARİH"].ToString());
                listView1.Items.Add(ekle);
            }
            con.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            int kayitSayisi = -1;
            using (OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =PASTANE.accdb"))
            {
                OleDbCommand cmd = new OleDbCommand("select count(*) from SATIS_HESAPALMA WHERE TARİH BETWEEN @TARİH1 AND @TARİH2", con);
                cmd.Parameters.Add("@TARİH1", OleDbType.Date).Value = dateTimePicker1.Value;
                cmd.Parameters.Add("@TARİH2", OleDbType.Date).Value = dateTimePicker2.Value;
                con.Open();
                kayitSayisi = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();
            }
            label3.Text = (kayitSayisi + " adet kayıt bulunmaktadır.");
        }
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int toplam = -1;
                using (OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =PASTANE.accdb"))
                {
                    OleDbCommand cmd = new OleDbCommand("select sum(FIYATI) from SATIS_HESAPALMA WHERE TARİH BETWEEN @TARİH1 AND @TARİH2", con);
                    cmd.Parameters.Add("@TARİH1", OleDbType.Date).Value = dateTimePicker1.Value;
                    cmd.Parameters.Add("@TARİH2", OleDbType.Date).Value = dateTimePicker2.Value;
                    con.Open();
                    toplam = Convert.ToInt32(cmd.ExecuteScalar());
                    label4.Text = (toplam + " TL");
                    con.Close();
                }
            }
            catch (Exception)
            {
                label4.Text = "0 TL";
            }
            
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            frmArama f1 = new frmArama();
            f1.Show();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 10);
            float offset = e.MarginBounds.Top;
            offset += (font.GetHeight() + 50.0f);
            PointF location = new System.Drawing.PointF(e.MarginBounds.Left, offset);
            e.Graphics.DrawString(columnHeader1.Text + "                  " + columnHeader2.Text + "                " + columnHeader3.Text + "                             " + columnHeader4.Text + "                         " + columnHeader5.Text + "                      ", font, Brushes.Black, location);
            e.Graphics.DrawString("  ", font, Brushes.Black, location);
            foreach (ListViewItem Item in listView1.Items)
            {
                offset += (font.GetHeight() + 50.0f);

                // The 5.0f is to add a small space between lines
                PointF locationn = new System.Drawing.PointF(e.MarginBounds.Left, offset);
                e.Graphics.DrawString(Item.SubItems[0].Text + "                       " + Item.SubItems[1].Text + "                        " + Item.SubItems[2].Text + "                           " + Item.SubItems[3].Text + "                    " + Item.SubItems[4].Text + "                                     ", font, Brushes.Black, locationn);
            }
        }

        private void baskıÖnizlemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog preview = new PrintPreviewDialog();

            preview.Document = printDocument1;
            // Then show the dialog window.
            preview.Show();
        }

        private void yazdırToolStripMenuItem_Click(object sender, EventArgs e)
        {

            PrintDocument printDocument1 = new PrintDocument();
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printDocument1.Print();
        }
    }
}
