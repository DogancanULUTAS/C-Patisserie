﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Drawing.Printing;

namespace pastane_otomasyonu
{
    public partial class frmPersonel : Form
    {
        public frmPersonel()
        {
            InitializeComponent();
            listele();
        }
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
        OleDbCommand cmd = new OleDbCommand();
        public void listele()
        {
            OleDbConnection baglan = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            DataSet dtst = new DataSet();
            OleDbDataAdapter adtr = new OleDbDataAdapter();
            listView1.Items.Clear();
            baglan.Open();
            OleDbCommand komut = new OleDbCommand();
            komut.Connection = baglan;
            komut.CommandText = ("Select * FROM PERSONELLER");
            OleDbDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                ListViewItem ekle = new ListViewItem();


                ekle.SubItems.Add(oku["SOYAD"].ToString());
                ekle.Text = oku["AD"].ToString();
                ekle.SubItems.Add(oku["YAŞ"].ToString());
                ekle.SubItems.Add(oku["TELEFON"].ToString());
                ekle.SubItems.Add(oku["PAROLA"].ToString());
                ekle.SubItems.Add(oku["KULLANICI_AD"].ToString());
                ekle.SubItems.Add(oku["Kimlik"].ToString());



                listView1.Items.Add(ekle);


            }

            baglan.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string secmeSorgusu = "SELECT * FROM PERSONELLER where KULLANICI_AD='" + textBox1.Text + "'";

            OleDbCommand secmeKomutu = new OleDbCommand(secmeSorgusu, con);
            secmeKomutu.Parameters.AddWithValue("@KULLANICI_AD", textBox1.Text);

            OleDbDataAdapter da = new OleDbDataAdapter(secmeKomutu);
            OleDbDataReader dr = secmeKomutu.ExecuteReader();

            if (dr.Read())
            {

                dr.Close();
                DialogResult durum = MessageBox.Show("Kaydı silmek istediğinizden emin misiniz?", "Silme Onayı", MessageBoxButtons.YesNo);
                if (DialogResult.Yes == durum)
                {
                    string silmeSorgusu = "DELETE from PERSONELLER where KULLANICI_AD=@KULLANICI_AD";

                    OleDbCommand silKomutu = new OleDbCommand(silmeSorgusu, con);
                    silKomutu.Parameters.AddWithValue("@KULLANICI_AD", textBox1.Text);
                    silKomutu.ExecuteNonQuery();
                    if (textBox1.Text == "")
                        MessageBox.Show("Kullanıcı adını giriniz.", "HATA");
                    else
                        MessageBox.Show("Kayıt silindi...");
                    listele();

                }
            }
            else
                MessageBox.Show("Kayıt bulunamadı.");
            con.Close();
            listele();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                textBox1.Text = item.SubItems[0].Text;
                textBox2.Text = item.SubItems[1].Text;
                textBox3.Text = item.SubItems[2].Text;
                textBox4.Text = item.SubItems[3].Text;
                textBox5.Text = item.SubItems[4].Text;
                textBox6.Text = item.SubItems[5].Text;
                textBox7.Text = item.SubItems[6].Text;



            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection bag = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");

            bag.Open();
            if (textBox7.Text != "")
            {
                
                {
                    string kayit = "update PERSONELLER set AD=@AD,SOYAD=@SOYAD,YAŞ=@YAŞ,TELEFON=@TELEFON,PAROLA=@PAROLA,KULLANICI_AD=@KULLANICI_AD where Kimlik=@Kimlik";
                    OleDbCommand komut = new OleDbCommand(kayit, bag);

                    komut.Parameters.AddWithValue("@AD", textBox1.Text);
                    komut.Parameters.AddWithValue("@SOYAD", textBox2.Text);
                    komut.Parameters.AddWithValue("@YAŞ", textBox3.Text);
                    komut.Parameters.AddWithValue("@TELEFON", textBox4.Text);
                    komut.Parameters.AddWithValue("@PAROLA", textBox5.Text);
                    komut.Parameters.AddWithValue("@KULLANICI_AD", textBox6.Text);
                    komut.Parameters.AddWithValue("@Kimlik", textBox7.Text);
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();

                    komut.ExecuteNonQuery();

                    bag.Close();
                    MessageBox.Show("Personel bilgileri güncellendi.");
                    listele();
                }



            }
            else
                MessageBox.Show("Güncellenicek kayıtı seçiniz.", "HATA");
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57)
            {
                e.Handled = false;//eğer rakamsa  yazdır.
            }

            else if ((int)e.KeyChar == ',' || ((int)e.KeyChar == 8))
            {
                e.Handled = false;//eğer basılan tuş backspace ise yazdır.
            }
            else
            {
                e.Handled = true;//bunların dışındaysa hiçbirisini yazdırma
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57)
            {
                e.Handled = false;//eğer rakamsa  yazdır.
            }

            else if ((int)e.KeyChar == ',' || ((int)e.KeyChar == 8))
            {
                e.Handled = false;//eğer basılan tuş backspace ise yazdır.
            }
            else
            {
                e.Handled = true;//bunların dışındaysa hiçbirisini yazdırma
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            OleDbCommand cmd = new OleDbCommand();
            con.Open();
            cmd.Connection = con;
            if (textBox7.Text != "")
            {
                DialogResult secenek = MessageBox.Show("Personeli silmek istiyor musunuz?", "Bilgilendirme Penceresi", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (secenek == DialogResult.Yes)
                {
                    cmd.CommandText = ("DELETE * FROM PERSONELLER WHERE Kimlik=" + textBox7.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Kayıt silindi.");
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();

                }
                cmd.Dispose();
                con.Close();
                listele();
            }
        }

        private void baskıÖnizlemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog preview = new PrintPreviewDialog();

            preview.Document = printDocument1;
            // Then show the dialog window.
            preview.Show();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 10);
            float offset = e.MarginBounds.Top;
            offset += (font.GetHeight() + 50.0f);
            PointF location = new System.Drawing.PointF(e.MarginBounds.Left, offset);
            e.Graphics.DrawString(columnHeader1.Text + "                  " + columnHeader2.Text + "                " + columnHeader3.Text + "                 " + columnHeader4.Text + "             " + columnHeader5.Text + "             " + columnHeader6.Text+"       ", font, Brushes.Black, location);
            e.Graphics.DrawString("  ", font, Brushes.Black, location);
            foreach (ListViewItem Item in listView1.Items)
            {
                offset += (font.GetHeight() + 50.0f);

                // The 5.0f is to add a small space between lines
                PointF locationn = new System.Drawing.PointF(e.MarginBounds.Left, offset);

                e.Graphics.DrawString(Item.SubItems[0].Text + "              " + Item.SubItems[1].Text + "                " + Item.SubItems[2].Text + "                   " + Item.SubItems[3].Text + "            " + Item.SubItems[4].Text+"                             "+ Item.SubItems[5].Text +"      ", font, Brushes.Black, locationn);
            }
        }

        private void yazdırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDocument printDocument1 = new PrintDocument();
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printDocument1.Print();
        }

        private void kullanıcıEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUyeEkle f1 = new frmUyeEkle();
            f1.Show();
        }

        private void kullanıcıŞifreDeğiştirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSifreDegistir f1 = new frmSifreDegistir();
            f1.Show();
        }
    }
}
