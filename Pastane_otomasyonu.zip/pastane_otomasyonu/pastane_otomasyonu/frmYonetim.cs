﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace pastane_otomasyonu
{
    public partial class frmYonetim : Form
    {
        public frmYonetim()
        {
            InitializeComponent();
            
        }
        
    


        private void button1_Click(object sender, EventArgs e)
        {
            frmPersonel f1 = new frmPersonel();
            f1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmMalzeme f1 = new frmMalzeme();
            f1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmMasaSiparis f1 = new frmMasaSiparis();
            f1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmAdresSiparis f1 = new frmAdresSiparis();
            f1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
        }
            

        private void button6_Click(object sender, EventArgs e)
        {
        }

        private void frmYonetim_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

           
            
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmPersonel f2 = new frmPersonel();
            f2.Show();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            frmSatis f1 = new frmSatis();
            f1.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
        }

        private void ekleToolStripMenuItem_Click(object sender, EventArgs e)
        {

            
        }

        private void silToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPersonel f1 = new frmPersonel();
            f1.Show();
        }

        private void malzemeListesiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMalzeme f1 = new frmMalzeme();
            f1.Show();
        }

        private void görüntüleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin f1 = new frmAdmin();
            f1.Show();
        }

        private void hesapBölümüToolStripMenuItem_Click(object sender, EventArgs e)
        {
     
            frmSatis f1 = new frmSatis();
            f1.Show();
        }

        private void masayaSiparişlerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMasaSiparis f1 = new frmMasaSiparis();
            f1.Show();
        }

        private void adreseSiparişlerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdresSiparis f1 = new frmAdresSiparis();
            f1.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = label1.Text.Substring(1) + label1.Text.Substring(0, 1);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void hesapBölümüToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void tariheGöreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmListeleme f1 = new frmListeleme();
            f1.Show();
        }

        private void ürünAdınaGöreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmArama f1 = new frmArama();
                f1.Show();
        }

        private void tariheGöreToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmMListeleme f1 = new frmMListeleme();
            f1.Show();
        }

        private void malzemeAdınaGöreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMArama f1 = new frmMArama();
            f1.Show();
        }

        private void şifreDeğiştirToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void raporÇıkarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void kullanıcılarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdmin f1 = new frmAdmin();
            f1.Show();
        }
    }
}
