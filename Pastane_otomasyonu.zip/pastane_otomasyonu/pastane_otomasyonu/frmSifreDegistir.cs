﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace pastane_otomasyonu
{
    public partial class frmSifreDegistir : Form
    {
        public frmSifreDegistir()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
       
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            
            if (textBox1.Text != "" || textBox2.Text != "")
            {
               
                OleDbCommand cmd = new OleDbCommand("Update PERSONELLER Set  PAROLA=@PAROLA WHERE KULLANICI_AD = '" + textBox1.Text + "' AND TELEFON = '" + maskedTextBox1.Text + "'", con);

                con.Open();
                    cmd.Parameters.AddWithValue("@PAROLA", textBox2.Text);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Şifreniz başarıyla değiştirilmiştir.");
                    
             
            }
            else
                MessageBox.Show("Lütfen tüm alanları doldurun.", "HATA");
      
            con.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
