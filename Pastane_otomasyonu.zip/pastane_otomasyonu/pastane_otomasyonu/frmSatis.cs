﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Drawing.Printing;


namespace pastane_otomasyonu
{
    public partial class frmSatis : Form
    {
        public frmSatis()
        {
            InitializeComponent();
            listele();
        }
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
        OleDbCommand cmd = new OleDbCommand();
        public void listele()
        {
            OleDbConnection baglan = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            DataSet dtst = new DataSet();
            OleDbDataAdapter adtr = new OleDbDataAdapter();
            listView1.Items.Clear();
            baglan.Open();
            OleDbCommand komut = new OleDbCommand();
            komut.Connection = baglan;
            komut.CommandText = ("Select * FROM SATIS_HESAPALMA");
            OleDbDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                ListViewItem ekle = new ListViewItem();


                ekle.SubItems.Add(oku["ADEDI"].ToString());
                ekle.Text = oku["Urun_adi"].ToString();
                ekle.SubItems.Add(oku["FIYATI"].ToString());
                ekle.SubItems.Add(oku["TARİH"].ToString());
                ekle.SubItems.Add(oku["Kimlik"].ToString());




                listView1.Items.Add(ekle);


            }

            baglan.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (comboBox1.Text.Trim() != "" && textBox2.Text.Trim() != "" && textBox3.Text.Trim() != "")
                {

                    


                    OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
                    OleDbCommand cmd = new OleDbCommand();
                    con.Open();

                    cmd.Connection = con;

                    cmd.CommandText = ("INSERT INTO SATIS_HESAPALMA(Urun_adi,ADEDI,FIYATI,TARİH) VALUES (@Urun_adi,@ADEDI,@FIYATI,@TARİH)");
                    cmd.Parameters.AddWithValue("@Urun_adi", comboBox1.Text);
                    cmd.Parameters.AddWithValue("@ADEDI", textBox2.Text);
                    cmd.Parameters.AddWithValue("@FIYATI", textBox3.Text);
                    cmd.Parameters.AddWithValue("@TARİH", dateTimePicker1);
                    cmd.Parameters.AddWithValue("@Kimlik", textBox4.Text);



                    cmd.ExecuteNonQuery();

                    cmd.Dispose();

                    con.Close();

                    

                    textBox2.Clear();

                    textBox3.Clear();
                    textBox4.Clear();
                    


                    MessageBox.Show("Kayıt işlemi tamamlandı ! ");
                    listele();
                }


                else
                {

                    MessageBox.Show("Boş alanları doldurunuz !!!");
                }
            }

            catch
            {

                MessageBox.Show("Bilinmeyen hata oluştu!","HATA");

            }
        }


        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int kayitSayisi = -1;
            using (OleDbConnection con = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source =PASTANE.accdb"))
            {
                OleDbCommand cmd = new OleDbCommand("select count(*) from SATIS_HESAPALMA", con);
                con.Open();
                kayitSayisi = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();
            }

            label6.Text = (kayitSayisi + " adet kayıt bulunmaktadır.");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            string islem = "select sum(FIYATI) from SATIS_HESAPALMA";
            baglanti.Open();
            OleDbCommand komut = new OleDbCommand(islem, baglanti);
            string toplam = komut.ExecuteScalar().ToString();
            komut.ExecuteNonQuery();
            label8.Text = (toplam + " TL");
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                textBox2.Text = item.SubItems[1].Text;
                comboBox1.Text  = item.SubItems[0].Text;
                textBox3.Text = item.SubItems[2].Text;
                dateTimePicker1.Text = item.SubItems[3].Text;
                textBox4.Text = item.SubItems[4].Text;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            OleDbCommand cmd = new OleDbCommand();
            con.Open();
            cmd.Connection = con;
            if (textBox4.Text != "")
            {
                DialogResult secenek = MessageBox.Show("Kaydı silmek istiyor musunuz?", "Bilgilendirme Penceresi", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (secenek == DialogResult.Yes)
                {
                    cmd.CommandText = ("DELETE * FROM SATIS_HESAPALMA WHERE Kimlik=" + textBox4.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Kayıt silindi.");
                   
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();



                }
                cmd.Dispose();
                con.Close();
                listele();
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            OleDbConnection bag = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");

            bag.Open();
            if (textBox4.Text != "")
            {
                string kayit = "update SATIS_HESAPALMA set Urun_adi=@Urun_adi,ADEDI=@ADEDI,FIYATI=@FIYATI,TARİH=@TARİH where Kimlik=@Kimlik";
                OleDbCommand komut = new OleDbCommand(kayit, bag);

                komut.Parameters.AddWithValue("@Urun_adi", comboBox1.Text);
                komut.Parameters.AddWithValue("@ADEDI", textBox2.Text);
                komut.Parameters.AddWithValue("@FIYATI", textBox3.Text);
                komut.Parameters.AddWithValue("@TARİH", dateTimePicker1);
                komut.Parameters.AddWithValue("@Kimlik", textBox4.Text);
              
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();

                komut.ExecuteNonQuery();

                bag.Close();
                MessageBox.Show("Ürün bilgileri güncellendi.");
                listele();
            }
            else
                MessageBox.Show("Güncellenicek kayıtı seçiniz.", "HATA");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void frmSatis_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Poğaça");
            comboBox1.Items.Add("Açma");
            comboBox1.Items.Add("Kaşarlı Pide");
            comboBox1.Items.Add("Simit");
            comboBox1.Items.Add("İçli Simit");
            comboBox1.Items.Add("Su Böreği");
            comboBox1.Items.Add("Kıymalı Börek");
            comboBox1.Items.Add("Profiterol");
            comboBox1.Items.Add("Güllaç");
            comboBox1.Items.Add("Tiramisu");
            comboBox1.Items.Add("Triliçe");
            comboBox1.Items.Add("Sütlaç");
            comboBox1.Items.Add("Çay");
            comboBox1.Items.Add("Nescafe");
            comboBox1.Items.Add("Türk Kahvesi");
            comboBox1.Items.Add("Su");
            comboBox1.Items.Add("Kola");
            comboBox1.Items.Add("Meyve Suyu");
            comboBox1.Items.Add("4 Kişi Pasta");
            comboBox1.Items.Add("6 Kişi Pasta");
            comboBox1.Items.Add("8 Kişi Pasta");
            comboBox1.Items.Add("10 Kişi Pasta");
            comboBox1.Items.Add("Ekmek");
            comboBox1.Items.Add("Ramazan Pidesi");
            comboBox1.Items.Add("Kahvaltı Tabağı");


        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            frmListeleme f1 = new frmListeleme();
            f1.Show();
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57)
            {
                e.Handled = false;//eğer rakamsa  yazdır.
            }

            else if ((int)e.KeyChar == ',' || ((int)e.KeyChar == 8))
            {
                e.Handled = false;//eğer basılan tuş backspace ise yazdır.
            }
            else
            {
                e.Handled = true;//bunların dışındaysa hiçbirisini yazdırma
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57)
            {
                e.Handled = false;//eğer rakamsa  yazdır.
            }

            else if ((int)e.KeyChar == ',' || ((int)e.KeyChar == 8))
            {
                e.Handled = false;//eğer basılan tuş backspace ise yazdır.
            }
            else
            {
                e.Handled = true;//bunların dışındaysa hiçbirisini yazdırma
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void tariheGöreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmListeleme f1 = new frmListeleme();
            f1.Show();
        }

        private void ismeGöreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmArama f1 = new frmArama();
            f1.Show();
        }

        private void baskıÖnizlemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog preview = new PrintPreviewDialog();

            preview.Document = printDocument1;
            // Then show the dialog window.
            preview.Show();
        }

        private void yazdırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDocument printDocument1 = new PrintDocument();
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 10);
            float offset = e.MarginBounds.Top;
            offset += (font.GetHeight() + 50.0f);
            PointF location = new System.Drawing.PointF(e.MarginBounds.Left, offset);
            e.Graphics.DrawString(columnHeader1.Text + "                " + columnHeader2.Text + "                 " + columnHeader3.Text + "                                       " + columnHeader5.Text + "                                      " + columnHeader4.Text + "                    ", font, Brushes.Black, location);
            e.Graphics.DrawString("  ", font, Brushes.Black, location);
            foreach (ListViewItem Item in listView1.Items)
            {
                offset += (font.GetHeight() + 50.0f);

                // The 5.0f is to add a small space between lines
                PointF locationn = new System.Drawing.PointF(e.MarginBounds.Left, offset);

                e.Graphics.DrawString(Item.SubItems[0].Text + "                   " + Item.SubItems[1].Text + "                               " + Item.SubItems[2].Text + "                                " + Item.SubItems[3].Text + "                            " + Item.SubItems[4].Text, font, Brushes.Black, locationn);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string turusec = comboBox1.SelectedItem.ToString();
            try
            {
                int adedi = Convert.ToInt32(textBox2.Text);
                int toplam;
                switch (turusec)
                {
                    case "Poğaça":

                        toplam = adedi * 1;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Açma":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 2;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Kaşarlı Pide":

                        toplam = adedi * 3;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Simit":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 1;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "İçli Simit":

                        toplam = adedi * 2;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Su Böreği":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 6;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Kıymalı Börek":

                        toplam = adedi * 8;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Profiterol":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 7;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Güllaç":

                        toplam = adedi * 7;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Triliçe":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 7;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Sütlaç":

                        toplam = adedi * 7;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Tiramisu":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 7;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Su":

                        toplam = adedi * 1;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Kola":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 3;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Meyve Suyu":

                        toplam = adedi * 2;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "4 Kişi Pasta":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 20;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "6 Kişi Pasta":

                        toplam = adedi * 30;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "8 Kişi Pasta":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 40;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "10 Kişi Pasta":

                        toplam = adedi * 50;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Ekmek":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 1;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Ramazan Pidesi":

                        toplam = adedi * 3;

                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Kahvaltı Tabağı":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 15;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Çay":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 2;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Nescafe":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 4;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                    case "Türk Kahvesi":
                        adedi = Convert.ToInt32(textBox2.Text);
                        toplam = adedi * 5;
                        textBox3.Text = Convert.ToString(toplam);
                        break;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lütfen önce ürün adedini giriniz.", "HATA");
            }
                   
            }

        }
    }


    

    
    



    

