﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace pastane_otomasyonu
{
    public partial class frmSifreUnuttum : Form
    {
        public frmSifreUnuttum()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = "Yanlış Giriş";
            label4.Visible = true;
            label3.Visible = false;
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
        
            con.Open();
  
            
                OleDbCommand komut = new OleDbCommand("Select PAROLA from PERSONELLER where KULLANICI_AD='" + textBox1.Text +
                    "' and TELEFON='" + textBox2.Text + "'", con);
                OleDbDataReader oku = komut.ExecuteReader();
                while (oku.Read())
                {
                    label4.Text = oku["PAROLA"].ToString();
                    label3.Visible = true;
                    label4.Visible = true;
                    return;
                    
            }
           
            con.Close();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
