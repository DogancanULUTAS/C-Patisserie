﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace pastane_otomasyonu
{
    public partial class frmHesapAl : Form
    {
        public frmHesapAl()
        {
            InitializeComponent();
        }
   
        private void button1_Click(object sender, EventArgs e)
        {
            OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            if (comboBox1.SelectedIndex != -1)
              
         
            {

                string islem = "select sum(FIYATI) from MASAYA_SİPARİS WHERE MASA_NO=" + comboBox1.Text;
                baglanti.Open();
                OleDbCommand komut = new OleDbCommand(islem, baglanti);
                string toplam = komut.ExecuteScalar().ToString();
                komut.ExecuteNonQuery();
                label1.Text = (toplam + " TL");
              


            }
            
            else
            MessageBox.Show("Masa no seçiniz.", "HATA");
        }

        private void frmHesapAl_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("1");
            comboBox1.Items.Add("2");
            comboBox1.Items.Add("3");
            comboBox1.Items.Add("4");
            comboBox1.Items.Add("5");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=PASTANE.accdb");
            OleDbCommand cmd = new OleDbCommand();
            con.Open();
            cmd.Connection = con;
            if (comboBox1.SelectedIndex != -1)
            {
                
                    cmd.CommandText = ("DELETE * FROM MASAYA_SİPARİS WHERE MASA_NO=" + comboBox1.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Masa silindi.");

                    



                }
                cmd.Dispose();
                con.Close();
              
            }
        }
    }

